import logo from './logo.svg';
import './App.css';
import {Link, Switch, Route, Redirect} from 'react-router-dom';
import Main from './components/Main'
import Create from './components/Create'
import Edit from './components/Edit'

function App() {
  return (
    <div className="App">
        <h1>Favorite Authors</h1>

        <Switch>
          <Route path={'/edit/:id'}>
            <Edit/>
          </Route>
          <Route path={'/new'}>
            <Create/>
          </Route>
          <Route path={'/'}>
            <Main/>
          </Route>
        </Switch>
    </div>
  );
}

export default App;
