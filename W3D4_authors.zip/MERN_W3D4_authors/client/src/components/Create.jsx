import React, {useState} from 'react';
import axios from 'axios';
import {useHistory} from 'react-router-dom';


const Create = (props)=>{
    const history = useHistory();
    const [name, setName] = useState("");
    const [errors, setErrors] = useState([])

    const createAuthor = (e) =>{
        e.preventDefault();
        
        const newAuthor = {
            Name: name
        }
        
        axios.post('http://localhost:8000/api/authors', newAuthor)
        .then(res=> {console.log(res.data);
            history.push("/")
        })
        .catch(err => {
            console.log("Error")
            console.log(err.response.data);

            const errorResponse = err.response.data.errors;
            const errorArr = [];
            for(const key of Object.keys(errorResponse)){
                errorArr.push(errorResponse[key].message)
            }
            setErrors(errorArr);

        })
    }


    return(
        <div>
            <h3>New Author Form</h3>

            {errors.map((err, index) => <p style={{color: 'red'}}key={index}>{err}</p>)}
            <form onSubmit={createAuthor}>
                Name:
                <input type="text" onChange={e => setName(e.target.value)} value={name}/>
                <button>Submit</button>
            </form>
        </div>
    )
}

export default Create;