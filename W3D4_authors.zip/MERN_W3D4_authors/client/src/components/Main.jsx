import React, {useState, useEffect} from 'react';
import axios from 'axios';
import {Link} from 'react-router-dom';


const Main = (props) => {
    
    ////////////Grabbing info from DB through our routes////////
    const [authors, setAuthors]=useState([]);

    useEffect( () =>{
        getAuthorsFromDB()
    }, [])

    const getAuthorsFromDB = () => {
        axios.get("http://localhost:8000/api/authors/")
        .then(res=>{
            setAuthors(res.data.author)
        })
        .catch(err=>console.log(err))
    }
////////////////////DELETE/////////////////////////////////////////
    const deleteAuthor = (deleteId) =>{
        axios.delete("http://localhost:8000/api/authors/"+ deleteId)
        .then(res =>{
            console.log(res);
            console.log("Success!")
            
            //remove from DOM after success
            setAuthors(authors.filter((author) => author._id !== deleteId))
        })
        .catch(err => console.log(err))
    }
///////////////////////////////////////////////////////////////

//////////Table using .map/////////////////////////////////////
    return (
        <div>
            <div>
                <Link to={"/new"}>Add an author</Link>
            </div>
            <div>
                <h5>We have quotes by:</h5>
            </div>
            <div>
                <table>
                    <thead>
                        <tr>
                            <th>Author</th>
                            <th>Actions Available</th>
                        </tr>
                    </thead>
                    <tbody>
                        {authors.map((author, idx)=>
                        <tr key={author._id}>
                            <td>
                                {author.Name}
                            </td>
                            <td>
                                <Link to={"/edit/"+author._id}>Edit</Link> &nbsp; 
                                <button onClick={()=>deleteAuthor(author._id)}>Delete</button>
                            </td>
                        </tr>
                        )
                    }
                    </tbody>
                </table>
            </div>

        </div>
    )
}

export default Main;