import React, { useState, useEffect } from 'react';
import { Link, useHistory, useParams } from 'react-router-dom';
import axios from 'axios';


const Edit = (props) => {

    let history = useHistory();

    const { id } = useParams();

    const [name, setName] = useState("");

    const [errors, setErrors] = useState([]);

    useEffect(() => {
        axios.get("http://localhost:8000/api/authors/" + id)
            .then(res => {
                console.log(res.data);
                setName(res.data.Name)

            })
            .catch(err => console.log(err))
    }, [])

    const onSubmitHandler = e => {
        e.preventDefault();
        const newAuthor = {
            Name: name,

        }
        axios.put("http://localhost:8000/api/authors/" + id, newAuthor)
            .then(res => {
                console.log("Response: ", res);
                history.push('/')
            })
            .catch(err => {
                console.log("Error")

                const errorResponse = err.response.data.errors;
                const errorArr = [];
                for (const key of Object.keys(errorResponse)) {
                    errorArr.push(errorResponse[key].message)
                }
                setErrors(errorArr);

            })
    }

    return (
        <div>
            {errors.map((err, index) => <p style={{ color: 'red' }} key={index}>{err}</p>)}
            <form onSubmit={onSubmitHandler}>
                <p>
                    <label>Name</label>
                    <input type="text" onChange={e => setName(e.target.value)} value={name} />
                </p>
                <input type="submit" /> &nbsp;
                <Link to={"/"}>Cancel</Link>
            </form>
        </div>

    )
}

export default Edit;