const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 8000;
const DB = "authors_db";

//middleware
app.use(cors(), express.json(), express.urlencoded({extended:true}));

//database - make sure path matches mongoose.config location in step4
require("./config/mongoose.config")(DB);

//connect routes - added in step7 app is being passed from author.routes
require("./routes/author.routes")(app)

app.listen(PORT, ()=> {
    console.log(`Server is up on port: ${PORT}`)
})