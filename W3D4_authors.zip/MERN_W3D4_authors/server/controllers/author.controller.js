const { response } = require("express");
const Author = require("../models/author.model");

module.exports = {
    //read
    findAll : (req, res) => {
        Author.find()
            .then(allAuthors => res.json({author: allAuthors}))
            .catch(err => res.json({error: err}))
    },
    findOne : (req, res) =>{
        Author.findById(req.params.id)
        .then(author => res.json(author))
        .catch(err => res.json({error: err}))
    },

    //create
    create : (req, res) =>{
        Author.create(req.body)
        .then(newAuthor => res.json(newAuthor))
        .catch(err => 
            {res.status(400).json(err)})
    },

    //update
    update : (req, res) =>{
        Author.findByIdAndUpdate(req.params.id, req.body, {
            new: true, runValidators: true})
        .then((updatedAuthor) => {
            res.json(updatedAuthor)
        })
        .catch(err => 
            {res.status(400).json(err)})
    },

    //delete
    delete : (req, res) =>{
        Author.findByIdAndDelete(req.params.id)
        .then(result => res.json(result))
        .catch(err => res.json({message: "error res", error: err}))
    }
}